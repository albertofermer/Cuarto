====================================================================================
*													     *
*			Implementación del Algoritmo: QLearning		     		     *
*													     *
*				Alberto Fernández Merchán					     *
*													     *
====================================================================================


***********************************************************************************	
*						EJECUCIÓN						    *
***********************************************************************************

Para ejecutar el algoritmo deberá seguir los siguientes pasos:
	
	1. Deberá tener instalada la librería de Python MatPlotLib para poder 
	visualizar la gráfica de resultados.

	2. Doble click al fichero QLearningLaberinto.jar

	3. Tenga en cuenta que la ejecución del fichero .jar solo se repite una vez. Seguramente la gráfica de resultados no se corresponda con la presentada en el PowerPoint ya que en esa se ha realizado la ejecución alrededor de 100 veces.


***********************************************************************************