# Punto de Comienzo para Rosenbrock : [0,0]
# Punto de Comienzo para Rastrigin: [1,1]